
import multiprocessing as mp
import time
import sys
import argparse
# import numpy as np
import random
import math
# import ISE

read_line = lambda l: list(map(int, l.split(' ')[:2]))


# 适用返向图储存网络结构
# module 1 图部分————————————————————————————————————————————————————————————————————————————————————

class Graph:
    """
    Implemented by adjacent map
    """
    def __init__(self, node_size):
        self.node_size = node_size
        self.adj = [set() for _ in range(node_size + 1)]
        self.weight = np.zeros(node_size + 1)
        self.res_adj = [set() for _ in range(node_size + 1)]
    def add_edge(self, u, v):
        self.adj[u].add(v)
        self.res_adj[v].add(u)

    def get_children(self, node):
        return self.adj[node]
        

    def get_weight(self, v):
        return self.weight[v]

    def cal_weight(self):
        in_degrees = [len(s) for s in self.res_adj]
        for i, degree in enumerate(in_degrees):
            if degree:
                self.weight[i] = 1 / degree

    def get_parents(self, node):
        return self.res_adj[node]

class Reverse_Graph:
    """
    Implemented by adjacent map
    """
    def __init__(self):
        self.rnet = dict()

    def add_node(self, node):
        if node not in self.rnet:
            self.rnet[node] = dict()

    def add_edge(self, st, et, wt):

        Reverse_Graph.add_node(self, st)
        Reverse_Graph.add_node(self, et)
        self.rnet[et][st] = wt

    def get_neighbors(self, cur_pt):
        if cur_pt in self.rnet:   return self.rnet[cur_pt].items()
        else:  return []


# module IC和LT_____________________________________________
def getrr_IC(node):
    # 当前的激活节点
    Activity_set = []
    # 添加上该激活节点
    Activity_set.append(node)
    # 所有已被影响过得节点
    All_active = []
    All_active.append(node)

    while Activity_set:
        new_Activity_set = []
        for each_seed in Activity_set:
            # 得到它们的未激活邻居
            inactive_neibors = graph.get_neighbors(each_seed)
            for node, wt in inactive_neibors:
                if node not in All_active:
                    if random.random() < wt:
                        All_active.append(node)
                        new_Activity_set.append(node)
        Activity_set = new_Activity_set
    return All_active


def getrr_LT(node):
    New_Activity = []
    New_Activity.append(node)
    Activity_set = node
    # -1 会比判断[]是否为空更快
    while Activity_set:
        new_Activity_set = []
        neighbors = graph.get_neighbors(Activity_set)
        if len(neighbors) == 0:
            break
        candidate = random.sample(neighbors, 1)[0][0]
        if candidate not in New_Activity:
            New_Activity.append(candidate)
            new_Activity_set = candidate
        Activity_set = new_Activity_set
    return New_Activity


# module 3 IMM__________________________________________________________________

def IMM(eps, l):       # 删除此处寄存器可能导致变慢
    l = l * (1 + math.log(2) / math.log(no_node))
    R = sampling(eps, l)
    Seeds_, noc = node_selection(R, seed_size)
    return Seeds_

def log_(n, k):    # 更改这可能导致变慢
    fraction = 0
    for i in range(k + 1, n + 1):
        fraction += math.log(i)
    for i in range(1, n - k + 1):
        fraction -= math.log(i)
    return fraction

def sampling(eps, l):
    global graph, worker, seed_size 
    R = []
    LB = 1
    # 一些之后会用到的变量 抽象到方法体首部
    n = no_node      # 网格点数
    k = seed_size   # 种子集大小
    n_exp = eps * math.sqrt(2)  # next exp
    log_reuse = log_(n, k)
    max_head = math.log2(n - 1)
    n_lambda = (( 2 + 2 * n_exp / 3) * (log_reuse + l * math.log(n) + math.log(math.log2(n))) * n) / pow(n_exp, 2) #next lambda
    create_worker(2) 

    for i in range(1, int(max_head + 1)): 
        x = n / (math.pow(2, i))
        taSeeds_ = n_lambda/x
        for index in range(2):
            worker[index].inQ.put((taSeeds_ - len(R)) / 2)
        for w in worker:
            RR_ = w.outQ.get()
            R += RR_
        Seed_i, fac = node_selection(R, k)
        if n * fac >= (1 + n_exp) * x:
            LB = n * fac / (1 + n_exp)
            break

    alpha = math.sqrt(l * math.log(n) + math.log(2))
    beta = math.sqrt((1 - 1 / math.e) * (log_reuse + l * math.log(n) + math.log(2)))
    lambda_star = 2 * n * pow(((1 - 1 / math.e) * alpha + beta), 2) * pow(eps, -2)
    theta = lambda_star / LB
    
    if theta - len(R) > 0:
        for i in range(2):
            worker[i].inQ.put((theta - len(R))/ 2)
        for w in worker:
            R_list = w.outQ.get()
            R += R_list  #讲新的RR加入R
    finish_worker()
    return R

def node_selection(R, k):
    rr_deg = [0 for i in range(no_node + 1)]
    rr_set = {}
    count = 0
    for j in range(0, len(R)):
        rr = R[j]
        for rs in rr:
            rr_deg[rs] += 1
            if rs not in rr_set:
                rr_set[rs] = []
            rr_set[rs].append(j)
    Seeds_ = set()
    for i in range(k):
        __max = rr_deg.index(max(rr_deg))
        Seeds_.add(__max)
        new_rr = len(rr_set[__max])
        count += new_rr
        index = []
        for _ in rr_set[__max]:
            index.append(_)
        for _ in index:
            rr = R[_]
            for rs in rr:
                rr_deg[rs] -= 1
                rr_set[rs].remove(_)
    fac = count/len(R)
    return Seeds_, fac



# module 4 多线程部分 套用给定的多进程模板————————————————————————————————————————————————————————————
class Worker(mp.Process):
    # def __init__(self, inQ, outQ, random_seed):
    def __init__(self, inQ, outQ):
        super(Worker, self).__init__(target=self.start)
        self.inQ = inQ
        self.outQ = outQ
        self.count = 0
        self.R = []
        
            
    def run(self):
        global model
        while True:
            task = self.inQ.get()
            while self.count < task:
                v = random.randint(1, no_node)
                if model == 'IC' : rr = getrr_IC(v)
                else: rr=getrr_LT(v)
                self.R.append(rr)
                self.count += 1
            self.outQ.put(self.R)
            self.R = []
            self.count = 0
     

def create_worker(num):
    global worker
    '''
    创建子进程备用
    :param num: 多线程数量
    '''
    for i in range(num):
        worker.append(Worker(mp.Queue(), mp.Queue()))
        # worker.append(Worker(mp.Queue(), mp.Queue(), np.random.randint(0, 10 ** 9)))
        worker[i].start()

def finish_worker():
    for w in worker:
        w.terminate()



# module 5   测试运行部分——————————————————————————————————————————————————————————————
# 载入文件
global no_node, no_edge, graph, seeds


# 命令行参数读取
graph = Reverse_Graph()
start = time.time()
termination = 10

'''
从命令行读参数示例1
# ''' 
parser = argparse.ArgumentParser()
parser.add_argument('-i', '--file_name', type=str)
parser.add_argument('-k', '--seed_sum', type=int)
parser.add_argument('-m', '--model', type=str)
parser.add_argument('-t', '--time_limit', type=int)


args = parser.parse_args()
network_path = args.file_name
seed_size = int(args.seed_sum)
model = args.model


with open(network_path, 'r') as f:
    lines = f.readlines()
    no_node = int(lines[0].split()[0])
    no_edge = int(lines[0].split()[1])
    for line in lines[1:]:
        s, e, wt = line.split()
        graph.add_edge(int(s), int(e), float(wt))


if __name__ == "__main__":
    worker = []
    eps = 0.05
    l = 1
    seeds = IMM(eps, l)
    for seed in seeds:  print(seed)
    end = time.time()
    # print(end - start)

    # 把输出的种子复制到seed1.txt文件夹内，然后用ISE跑 python ISE.py -i NetHEPT.txt -s seed1.txt -m IC -t 10000
    


